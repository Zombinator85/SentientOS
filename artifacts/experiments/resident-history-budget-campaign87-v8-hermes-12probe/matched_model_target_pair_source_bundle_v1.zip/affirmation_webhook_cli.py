#  _____  _             _
# |  __ \| |           (_)
# | |__) | |_   _  __ _ _ _ __   __ _
# |  ___/| | | | |/ _` | | '_ \ / _` |
# | |    | | |_| | (_| | | | | | (_| |
# |_|    |_\__,_|\__, |_|_| |_|\__, |
#                  __/ |         __/ |
#                 |___/         |___/
from __future__ import annotations
"""Sanctuary Privilege Ritual: Do not remove. See doctrine for details."""
from sentientos.privilege import require_admin_banner, require_lumos_approval
require_admin_banner()
require_lumos_approval()
import argparse
import json
import os
from datetime import datetime
from typing import Any
import daily_theme
try:
    import requests  # type: ignore[import-untyped]  # HTTP client optional
except Exception:  # pragma: no cover - optional
    requests = None

def post_affirmation(url: str, mood: str | None = None) -> dict[str, Any]:
    data = {
        "timestamp": datetime.utcnow().isoformat(),
        "theme": daily_theme.generate(),
        "mood": mood or "",
    }
    if requests is None:
        raise RuntimeError("requests not available")
    r = requests.post(url, json=data, timeout=10)
    return {"status_code": r.status_code, "data": data}


def main() -> None:
    ap = argparse.ArgumentParser(description="Affirmation webhook")
    ap.add_argument("url")
    ap.add_argument("--mood")
    args = ap.parse_args()
    try:
        res = post_affirmation(args.url, args.mood)
        print(json.dumps(res, indent=2))
    except Exception as e:  # pragma: no cover - network
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
