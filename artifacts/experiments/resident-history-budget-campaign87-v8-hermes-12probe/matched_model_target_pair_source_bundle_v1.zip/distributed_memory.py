"""Distributed memory synchronisation across SentientOS nodes."""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import secrets
import socket
import threading
import time
from datetime import datetime, timezone
from typing import Dict, Mapping, Optional

from types import SimpleNamespace

try:
    import requests
except Exception as exc:  # pragma: no cover - optional dependency
    logging.getLogger(__name__).warning("[MemorySync] requests unavailable (%s); using stub.", exc)

    class _RequestsStubException(Exception):
        pass

    def _requests_stub_post(*_args, **_kwargs):
        raise _RequestsStubException("requests unavailable")

    requests = SimpleNamespace(post=_requests_stub_post, RequestException=_RequestsStubException)
from dotenv import load_dotenv

# Load explicit local configuration before node_registry snapshots NODE_TOKEN.
load_dotenv()

import memory_manager as mm
from node_registry import NODE_TOKEN, registry
from secure_memory_storage import AESGCM

try:  # pragma: no cover - optional dependency
    import zstandard as zstd
except Exception:  # pragma: no cover - optional dependency
    zstd = None  # type: ignore

load_dotenv()

LOGGER = logging.getLogger(__name__)

_SYNC_INTERVAL_SECONDS = float(os.getenv("SENTIENTOS_MEMORY_SYNC_INTERVAL", "30"))
_REMOTE_TIMEOUT = 8.0
_HEADER_TOKEN = "X-Node-Token"
_MEMORY_ENDPOINT = "/memory/export"
_COMPRESSED_ENCODING = "base64+zstd"
_REFLECTION_ENDPOINT = "/reflect/sync"
_REFLECTION_ENCODING = "aesgcm+base64"
_REFLECTION_ASSOCIATED_DATA = b"sentientos-reflection-v1"
_NODE_ID_HEADER = "X-Node-Id"
_MAX_SYNC_PAYLOAD_BYTES = 32 * 1024 * 1024
_MAX_SYNC_FRAGMENTS = 4096
_MAX_SYNC_FRAGMENT_BYTES = 262144


def _local_node_id() -> str:
    node_id = registry.local_hostname
    if node_id:
        return node_id
    return socket.gethostname()


def _derive_reflection_key() -> bytes:
    if not NODE_TOKEN:
        raise ValueError("NODE_TOKEN required for reflection synchronisation")
    seed = f"{NODE_TOKEN}|reflection-sync".encode("utf-8")
    return hashlib.sha256(seed).digest()


def encrypt_reflection_summary(summary: Mapping[str, object]) -> Dict[str, str]:
    """Return an AES-GCM envelope for the provided *summary*."""

    aesgcm = AESGCM(_derive_reflection_key())
    nonce = secrets.token_bytes(12)
    payload = json.dumps(dict(summary), ensure_ascii=False).encode("utf-8")
    ciphertext = aesgcm.encrypt(nonce, payload, _REFLECTION_ASSOCIATED_DATA)
    envelope: Dict[str, str] = {
        "nonce": base64.b64encode(nonce).decode("ascii"),
        "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
        "encoding": _REFLECTION_ENCODING,
        "version": "1",
    }
    summary_id = summary.get("reflection_id") or summary.get("id")
    if summary_id:
        envelope["summary_id"] = str(summary_id)
    return envelope


def decrypt_reflection_payload(payload: Mapping[str, object]) -> Dict[str, object]:
    """Decrypt and return the reflection summary contained in *payload*."""

    encoding = str(payload.get("encoding") or _REFLECTION_ENCODING).lower()
    if encoding not in {_REFLECTION_ENCODING, "aesgcm"}:
        raise ValueError("unsupported_encoding")
    nonce_b64 = payload.get("nonce")
    ciphertext_b64 = payload.get("ciphertext")
    if not isinstance(nonce_b64, str) or not isinstance(ciphertext_b64, str):
        raise ValueError("invalid_envelope")
    try:
        nonce = base64.b64decode(nonce_b64)
        ciphertext = base64.b64decode(ciphertext_b64)
    except Exception as exc:  # pragma: no cover - defensive
        raise ValueError("invalid_envelope") from exc
    aesgcm = AESGCM(_derive_reflection_key())
    try:
        plaintext = aesgcm.decrypt(nonce, ciphertext, _REFLECTION_ASSOCIATED_DATA)
    except Exception as exc:  # pragma: no cover - defensive
        raise ValueError("decryption_failed") from exc
    data = json.loads(plaintext.decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("invalid_payload")
    return data


def _parse_timestamp(timestamp: str) -> float:
    try:
        if timestamp.endswith("Z"):
            timestamp = timestamp[:-1] + "+00:00"
        return datetime.fromisoformat(timestamp).timestamp()
    except Exception:
        return 0.0


def encode_payload(payload: Dict[str, object], *, allow_compression: bool = False) -> tuple[bytes, Dict[str, str]]:
    """Return a payload ready for HTTP transmission.

    When ``allow_compression`` is true and :mod:`zstandard` is available the
    payload is compressed and base64 encoded to keep transport simple.
    """

    raw = json.dumps(payload).encode("utf-8")
    if len(raw) > _MAX_SYNC_PAYLOAD_BYTES:
        raise ValueError("memory_sync_payload_size_limit")
    headers: Dict[str, str] = {"Content-Type": "application/json"}
    if allow_compression and zstd:
        compressor = zstd.ZstdCompressor()
        compressed = compressor.compress(raw)
        headers["Content-Encoding"] = _COMPRESSED_ENCODING
        return base64.b64encode(compressed), headers
    return raw, headers


def _read_bounded_response(response: object) -> bytes:
    iterator = getattr(response, "iter_content", None)
    if not callable(iterator):
        raise ValueError("memory_sync_streaming_response_required")
    chunks: list[bytes] = []
    total = 0
    for chunk in iterator(chunk_size=65_536):
        if not chunk:
            continue
        total += len(chunk)
        if total > _MAX_SYNC_PAYLOAD_BYTES:
            raise ValueError("memory_sync_payload_size_limit")
        chunks.append(bytes(chunk))
    return b"".join(chunks)


def _decompress_payload(data: bytes, encoding: str | None) -> Dict[str, object]:
    if len(data) > _MAX_SYNC_PAYLOAD_BYTES:
        raise ValueError("memory_sync_payload_size_limit")
    if encoding == _COMPRESSED_ENCODING:
        if not zstd:
            raise ValueError("memory_sync_compression_unavailable")
        decoded = base64.b64decode(data, validate=True)
        if len(decoded) > _MAX_SYNC_PAYLOAD_BYTES:
            raise ValueError("memory_sync_compressed_size_limit")
        decompressor = zstd.ZstdDecompressor()
        restored = decompressor.decompress(decoded,
            max_output_size=_MAX_SYNC_PAYLOAD_BYTES + 1)
        if len(restored) > _MAX_SYNC_PAYLOAD_BYTES:
            raise ValueError("memory_sync_decompressed_size_limit")
        value = json.loads(restored.decode("utf-8"))
    else:
        value = json.loads(data.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("memory_sync_payload_invalid")
    return value


def _local_fragments() -> Dict[str, dict]:
    fragments: Dict[str, dict] = {}
    for fragment in mm.iter_fragments(reverse=False):
        fragment_id = fragment.get("id")
        if fragment_id:
            fragments[str(fragment_id)] = fragment
    return fragments


def _fragment_digest(fragment: Mapping[str, object]) -> str:
    value = dict(fragment)
    metadata = value.get("meta")
    if isinstance(metadata, dict) and "federation_import" in metadata:
        metadata = dict(metadata)
        metadata.pop("federation_import", None)
        value["meta"] = metadata
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"),
        ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _write_fragment(fragment: dict) -> bool:
    fragment_id = fragment.get("id")
    if not isinstance(fragment_id, str) or not fragment_id:
        return False
    try:
        # Use the shared owner so remote reconciliation cannot bypass local
        # mutation admission, canonical-retention exclusions, or atomic custody.
        mm._write_fragment(fragment_id, fragment)  # type: ignore[attr-defined]
        return True
    except (OSError, ValueError):
        LOGGER.warning("Rejected synchronised fragment %s by local memory custody",
            fragment_id, exc_info=True)
        return False


class DistributedMemorySynchronizer:
    """Periodically reconcile memory fragments with neighbouring nodes."""

    def __init__(self, interval_seconds: float = _SYNC_INTERVAL_SECONDS) -> None:
        self._interval = interval_seconds
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._lock = threading.Lock()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        if not NODE_TOKEN:
            LOGGER.warning("Memory federation requires NODE_TOKEN; skipping start.")
            return
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        banner = f"[SentientOS] Memory federation enabled (interval = {int(self._interval)} s)"
        LOGGER.info(banner)
        print(banner)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=0.5)

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self._sync_once()
            except Exception as exc:  # pragma: no cover - defensive
                LOGGER.warning("Memory synchronisation step failed: %s", exc, exc_info=True)
            self._stop.wait(self._interval)

    def _sync_once(self) -> None:
        local_fragments = _local_fragments()
        nodes = list(registry.iter_remote_nodes(trusted_only=True))
        if not nodes:
            return
        for node in nodes:
            self._merge_from_node(node.serialise(), local_fragments)

    def broadcast_reflection(self, summary: Mapping[str, object]) -> None:
        """Send ``summary`` to all trusted peers."""

        if not NODE_TOKEN:
            return
        if not summary:
            return
        nodes = list(registry.iter_remote_nodes(trusted_only=True))
        if not nodes:
            return
        snapshot = {k: v for k, v in dict(summary).items() if v is not None}
        snapshot.setdefault("sent_at", datetime.now(timezone.utc).isoformat())
        try:
            payload = encrypt_reflection_summary(snapshot)
        except ValueError:
            LOGGER.debug("Reflection broadcast skipped: encryption unavailable")
            return
        headers = {
            _HEADER_TOKEN: NODE_TOKEN,
            "Content-Type": "application/json",
            _NODE_ID_HEADER: _local_node_id(),
        }
        with self._lock:
            for node in nodes:
                url = f"http://{node.ip}:{node.port}{_REFLECTION_ENDPOINT}"
                try:
                    response = requests.post(url, json=payload, headers=headers, timeout=_REMOTE_TIMEOUT)
                except requests.RequestException as exc:  # pragma: no cover - defensive
                    LOGGER.debug("Reflection sync to %s failed: %s", node.hostname, exc)
                    continue
                if response.status_code >= 400:
                    LOGGER.debug(
                        "Reflection sync to %s returned %s",
                        node.hostname,
                        response.status_code,
                    )

    def _merge_from_node(self, node: Dict[str, object], local_cache: Dict[str, dict]) -> None:
        ip = node.get("ip")
        port = node.get("port", 5000)
        hostname = node.get("hostname", "unknown")
        if not ip:
            return
        url = f"http://{ip}:{port}{_MEMORY_ENDPOINT}"
        headers = {_HEADER_TOKEN: NODE_TOKEN,
            _NODE_ID_HEADER: _local_node_id()}
        try:
            response = requests.get(url, headers=headers, timeout=_REMOTE_TIMEOUT, stream=True)
        except requests.RequestException as exc:
            LOGGER.debug("Memory fetch from %s failed: %s", hostname, exc)
            return
        try:
            if response.status_code != 200:
                LOGGER.debug("Memory fetch from %s returned %s", hostname, response.status_code)
                return
            encoding = response.headers.get("Content-Encoding")
            payload = _decompress_payload(_read_bounded_response(response), encoding)
        except (OSError, ValueError, json.JSONDecodeError, UnicodeError) as exc:
            LOGGER.warning("Rejected bounded memory snapshot from %s: %s", hostname, exc)
            return
        finally:
            response.close()
        fragments = payload.get("fragments")
        if (not isinstance(fragments, list)
                or len(fragments) > _MAX_SYNC_FRAGMENTS):
            LOGGER.warning("Rejected memory snapshot with invalid fragment count from %s", hostname)
            return
        updates = 0
        for fragment in fragments:
            if not isinstance(fragment, dict):
                continue
            fragment_id = fragment.get("id")
            timestamp = fragment.get("timestamp")
            if (not isinstance(fragment_id, str) or not fragment_id
                    or not isinstance(timestamp, str)
                    or _parse_timestamp(timestamp) <= 0):
                LOGGER.warning("Rejected synchronized memory with incomplete identity/time")
                continue
            try:
                fragment_bytes = json.dumps(fragment, ensure_ascii=False).encode("utf-8")
            except (TypeError, ValueError):
                LOGGER.warning("Rejected noncanonical synchronized memory from %s", hostname)
                continue
            if len(fragment_bytes) > _MAX_SYNC_FRAGMENT_BYTES:
                LOGGER.warning("Rejected oversized synchronized memory identity %s", fragment_id)
                continue
            local_fragment = local_cache.get(fragment_id)
            if local_fragment is not None:
                if _fragment_digest(local_fragment) != _fragment_digest(fragment):
                    LOGGER.warning("Conflicting synchronized memory identity %s; preserving local record",
                        fragment_id)
                continue
            try:
                existing_raw = mm._read_legacy_raw_fragment(fragment_id + ".json")  # type: ignore[attr-defined]
            except (OSError, ValueError):
                LOGGER.warning("Could not verify existing memory identity %s; preserving custody state",
                    fragment_id, exc_info=True)
                continue
            if existing_raw is not None:
                try:
                    existing = json.loads(existing_raw.decode("utf-8"))
                except (UnicodeError, json.JSONDecodeError):
                    LOGGER.warning("Existing memory identity %s is malformed; refusing replacement",
                        fragment_id)
                    continue
                if not isinstance(existing, dict) or _fragment_digest(existing) != _fragment_digest(fragment):
                    LOGGER.warning("Conflicting stored memory identity %s; refusing replacement",
                        fragment_id)
                continue
            import_copy = dict(fragment)
            metadata = import_copy.get("meta")
            if metadata is None:
                metadata = {}
            elif not isinstance(metadata, dict):
                LOGGER.warning("Rejected memory identity %s with invalid metadata", fragment_id)
                continue
            else:
                metadata = dict(metadata)
            prior_import = metadata.get("federation_import")
            if prior_import is None:
                metadata["federation_import"] = {
                    "received_from_peer": str(hostname),
                    "source_fragment_digest": _fragment_digest(fragment),
                    "provenance_status": "registry_target_claim_not_signed_response_or_authorship_proof",
                }
            elif (not isinstance(prior_import, dict)
                    or prior_import.get("source_fragment_digest") != _fragment_digest(fragment)):
                LOGGER.warning("Rejected conflicting peer provenance for identity %s", fragment_id)
                continue
            import_copy["meta"] = metadata
            if _write_fragment(import_copy):
                local_cache[fragment_id] = import_copy
                updates += 1
        if updates:
            LOGGER.info("[Memory] Synced %s fragments from %s", updates, hostname)


synchronizer = DistributedMemorySynchronizer()


def _relay_reflection(summary: dict) -> None:
    try:
        synchronizer.broadcast_reflection(summary)
    except Exception:  # pragma: no cover - defensive
        LOGGER.debug("Reflection broadcast failed", exc_info=True)


try:
    mm.add_reflection_listener(_relay_reflection)
except AttributeError:  # pragma: no cover - legacy fallback
    LOGGER.debug("Reflection listener registration unavailable")

__all__ = [
    "DistributedMemorySynchronizer",
    "decrypt_reflection_payload",
    "encode_payload",
    "encrypt_reflection_summary",
    "synchronizer",
]
