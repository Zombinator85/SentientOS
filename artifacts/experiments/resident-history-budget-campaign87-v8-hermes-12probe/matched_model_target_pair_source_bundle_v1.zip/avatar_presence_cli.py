#  _____  _             _
# |  __ \| |           (_)
# | |__) | |_   _  __ _ _ _ __   __ _
# |  ___/| | | | |/ _` | | '_ \ / _` |
# | |    | | |_| | (_| | | | | | (_| |
# |_|    |_\__,_|\__, |_|_| |_|\__, |
#                  __/ |         __/ |
#                 |___/         |___/
from __future__ import annotations
"""Record avatar invocation and presence blessing.

This CLI logs each time an avatar is invoked for a specific reason.
A presence affirmation is stored with a blessing message.
"""
from sentientos.privilege import require_admin_banner, require_lumos_approval
from logging_config import resolve_log_path
import argparse
import json
import os
from datetime import datetime
from pathlib import Path


LOG_PATH = resolve_log_path("avatar_presence.jsonl", "AVATAR_PRESENCE_LOG")


def log_invocation(path: str, reason: str, mode: str = "visual") -> dict:
    require_admin_banner()
    require_lumos_approval()
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "avatar": path,
        "mode": mode,
        "reason": reason,
        "blessing": f"Avatar crowned for {reason}",
    }
    with LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
    return entry


def main() -> None:
    ap = argparse.ArgumentParser(description="Invoke avatar with blessing")
    ap.add_argument("avatar")
    ap.add_argument("reason")
    ap.add_argument("--mode", default="visual")
    args = ap.parse_args()
    entry = log_invocation(args.avatar, args.reason, args.mode)
    print(json.dumps(entry, indent=2))


if __name__ == "__main__":
    main()
