# Stateful import lifecycle recovery handoff

This archive preserves exact uncommitted task work and selected acceptance evidence. It is recovery custody only, not validation authority, landing authority, a commit, or publication.

## Restore on a canonical development substrate

1. Start from an exact clean checkout of `ce4a8e25a5e08dce6353c7aea8170c3d7acef6ea`. Verify both the HEAD SHA and tree SHA `3e0ff340e4de53e2072a5cdf8b4d04825f31a783`, branch context as appropriate, and clean status before restoration.
2. Verify the archive digest supplied with this handoff. Extract it, then verify `manifest.json`, the patch digest/length, and every included untracked file digest/length against that manifest.
3. From the repository root, apply `tracked_changes.patch` with `git apply --binary /path/to/extracted/tracked_changes.patch`.
4. Copy each file under `untracked/` into the repository at the same relative path after `untracked/`.
5. Compare `git status --short --untracked-files=all` with the manifest inventory, accounting for the manifest's explicitly excluded runtime-generated dirty paths. Confirm no unexpected changes.
6. Prior validation is historical evidence only; it is not current landing authority after restoration. Rerun task acceptance and all required current validation.
7. First reproduce `tests/test_dashboard_drift_api.py::test_drift_recent_rejects_invalid_n` on the root-capable substrate. If that unchanged node passes there, run the required broad suite. If it also hangs against the clean base there, classify it as an independent mainline validation blocker rather than changing this lifecycle repair.
8. Use the default SOLO landing profile, not the 131-lane exhaustive matrix unless current doctrine explicitly changes. Require pre-commit `ready_to_commit` before committing. Then complete the post-commit/PR-metadata finalizer, PR metadata guard, exact body binding, and publication handoff under current repository doctrine.

## Preserved validation summary

- Pytest bootstrap: `pytest_bootstrap_ready`.
- Prompt boundary: `boundary_clean`.
- Exact task acceptance: 41 call-phase nodes passed, `task_acceptance_ready`.
- Compilation: passed.
- `git diff --check`: passed.
- Targeted mypy compared with clean base: zero new diagnostics.
- Mypy baseline: `mypy_baseline_improved`.
- Broad `python -m scripts.run_tests -q`: incomplete; stalls around 46%.
- Exact unchanged dashboard drift `TestClient` reproduction: hangs at `TestClient.__enter__` / AnyIO portal.
- Strict audits: not run on this substrate.
- Immutability verifier: not run on this substrate.
- Finalizer: not invoked.
- Current Cloud substrate: UID/GID 1000, no passwordless sudo, unusable Docker daemon, no Podman/nerdctl.
- Landing posture: implementation/task-acceptance complete; canonical landing unproven and blocked on available execution substrate / incomplete required broad validation.

## Causal scope

This task repairs the historical import/state lifecycle class: definition/import != activation, persisted-state hydration, authority, or effect. It does not include memory_cli normalization, model_bridge normalization, unrelated legacy datetime cleanup, or a new repository-wide privilege campaign.
